package Polecenie_3;

public class Punkt_1 {
    public class Student {

        /*
         * Copyright (C) 2021,2022 by Lublin University of Technology.
         * All rights reserved.
         * Released under the terms of the GNU General Public License version 2 or later.
         */

        private String studentName;
        private int studentIndex;
        private Logger logger;

        /**
         * Konstruktor klasy Student.
         * @param studentName imię i nazwisko studenta
         * @param studentIndex indeks studenta
         */
        Student(String studentName, int studentIndex) {
            this.studentName = studentName;
            this.studentIndex = studentIndex;
            logger.info("Student: {} created.", studentName);
        }

        /**
         * Publikuje oceny studenta od podanej daty.
         * @param date data, od której oceny mają być publikowane
         * @param studentIndex indeks studenta
         * @return Lista obiektów typu Mark
         * @since 16.0
         */
        public List<Mark> publishStudentMarks(Date date, int studentIndex) {
            // some business logic here
            return new ArrayList<>();
        }

        /**
         * Ustawia promocję studenta na podstawie wykładu.
         * @param student obiekt studenta
         * @param lecture obiekt wykładu
         * @return zaktualizowany obiekt Student
         */
        public Student setStudentPromotion(Student student, Lecture lecture) {
            // some business logic here
            return student;
        }

        /**
         * Zwraca studenta piątego roku.
         * @return obiekt Student dla studenta piątego roku
         */
        public Student getFifthYearStudent() {
            // some business logic here
            return new Student("Last Year Student", 99999);
        }

        /**
         * Przeprowadza studenta przez proces ukończenia studiów.
         */
        public void graduateStudent() {
            // some business logic here
        }

        // TODO: rozszerzyć tę metodę - Feature 10.1
        public void checkStudentAbsence() {
            // some business logic here
        }
    }

}
