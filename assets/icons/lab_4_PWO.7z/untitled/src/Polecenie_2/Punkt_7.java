package Polecenie_2;

public class Punkt_7 {

    public List<Privilege> getEmployeePrivileges(long idCountry, long idCompany, long idDepartment, long idDepartmentEmployee) {
        Country country = countryRepository.findById(idCountry);
        if (country == null) return Collections.emptyList();

        Company company = country.getCompany(idCompany);
        if (company == null) return Collections.emptyList();

        Department department = company.getDepartment(idDepartment);
        if (department == null) return Collections.emptyList();

        Employee employee = department.getEmployee(idDepartmentEmployee);
        return (employee != null) ? employee.getPermissions() : Collections.emptyList();
    }


}
