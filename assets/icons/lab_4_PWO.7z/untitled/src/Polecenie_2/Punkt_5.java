package Polecenie_2;

public class Punkt_5 {

    public int saveGameResult(Player player, Result result) {
        if (player.getCountry().equals("Poland") && result.getScore() > 1000) {
            player.setWinCount(player.getWinCount() + 1);
        }
        return gameRepository.save(player, result);
    }


}
