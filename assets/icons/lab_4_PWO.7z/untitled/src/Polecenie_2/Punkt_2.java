package Polecenie_2;

public class Punkt_2 {

    @RestController
    @RequestMapping("/api")
    public class DocumentController {
        @PostMapping("/document")
        public User saveDocument(@RequestBody Document doc) {
            return documentService.saveDocumentWithSessionUser(doc);
        }
    }

    @Service
    public class DocumentService {
        @Autowired
        private DocumentRepository documentRepository;
        @Autowired
        private SessionRepository sessionRepository;

        public User saveDocumentWithSessionUser(Document doc) {
            doc.setCreationDate(new Date());
            doc.setCreator(getCurrentUserId());
            return documentRepository.save(doc);
        }

        private long getCurrentUserId() {
            return sessionRepository.getCurrentUser().getId();
        }
    }


}
