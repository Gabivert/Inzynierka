package Polecenie_2;

public class Punkt_1 {

    public void saveProductData(String productName, double price) {
        productRepository.save(productName);
        priceRepository.save(price);
    }

    public void recordPurchase(String productName, double price) {
        shopRepository.newPurchase(productName, price);
        userRepository.updateUserPurchase(getCurrentUser(), productName, price);
    }

}
