package Polecenie_2;

public class Punkt_6 {

    public boolean checkUser(long userId, Token token) {
        return verifyUser(userId, token);
    }

    public User updateUser(long userId, Token token, String userName, String userTelNumber) {
        if (verifyUser(userId, token)) {
            User user = userRepository.findById(userId);
            user.setTel(userTelNumber);
            return userRepository.save(user);
        }
        return null;
    }

    private boolean verifyUser(long userId, Token token) {
        User user = userRepository.findById(userId);
        return userRepository.verifyUser(user, token);
    }


}
