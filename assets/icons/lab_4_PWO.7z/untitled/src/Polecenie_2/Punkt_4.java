package Polecenie_2;

public class Punkt_4 {

    public void modifyAllParametersOfSummerTripPlan(TripPlan trip, TripDetails details) {
        tripRepository.save(trip);
        eMailService.send(details);
    }

    public class TripDetails {
        private List<Member> members;
        private List<Ticket> tickets;
        private List<Item> itemsToTake;
        private List<MedicalInformation> medInfos;
        private Accomodation[] sleepPlaces;
        private Contact[] contacts;
        private Weather weatherInformation;
        private Date startTripDate;
        private Date endTripDate;
        private Date[] tripMiddleDates;

        // Konstruktor i gettery/settery
    }


}
