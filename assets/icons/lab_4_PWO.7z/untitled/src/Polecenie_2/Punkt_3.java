package Polecenie_2;

public class Punkt_3 {

    public List<Product> updateProduct(long idProduct, String productName) {
        Product product = productRepository.findById(idProduct);
        productRepository.setName(productName);
        productRepository.save(product);

        List<Product> products = productRepository.findAll();
        for (int i = 0; i < products.size(); i++) {
            System.out.println(products.get(i));
        }

        return products;
    }


}
