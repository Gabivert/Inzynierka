package Polecenie_1;

public class Punkt_6 {

    public class ShopController extends RestController{…}
    public interface DriverRepository extends CrudRepository{…}
    public class FoodService extends Service{…}
    public class PaymentFacade extend Facade{…}

}
