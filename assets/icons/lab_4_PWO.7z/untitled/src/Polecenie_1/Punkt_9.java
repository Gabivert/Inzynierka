package Polecenie_1;

public class Punkt_9 {

    final double PI = 3.14;
    final int SECONDS_IN_AN_HOUR = 3600;
    final int ALARM_TYPE_DEFAULT = 4;
    int userStatus;
    int result;

    if (userStatus == 1 || (userStatus > 2 && userStatus < 5) || userStatus == 8) {
        System.out.println("User has appropriate permissions");
        result = triggerAlarm(ALARM_TYPE_DEFAULT, 9, 15, "user");
        switch (result) {
            case 0:
                executeFirstProcess();
                break;
            case 1:
                executeSecondProcess(result);
                break;
            case 3:
                executeFifthProcess(SECONDS_IN_AN_HOUR);
                break;
            default:
                executeThirdProcess(2022);
        }
    }


}
