package Polecenie_1;

public class Punkt_5 {

    public class HospitalVisit{
        public Patient createPatient(String name, String identity) {…}
        public Visit createVisit(Date d, Patient p){…}
        public VisitReport createVisitReport(Date d, Patient p, Visit v){…}
    }

}
