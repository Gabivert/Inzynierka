package Polecenie_1;

public class Punkt_7 {

    public class Car extends Vehicle{
        private String Brand; // zmienione nazwy zmiennych
        private String Type;
        private String RegistrationNumber;
        public Car getCar(){
            return this;
        }
        public void setCar(Car car){
            this.RegistrationNumber = car.getRegistrationNumber();
        }
        public void updateBrand(Car car){
            this.Brand = car.getBrand();
        }
        public void updateType(Car car){
            this.Type = car.getModel();
        }
        //Setters and getters
    }

}

