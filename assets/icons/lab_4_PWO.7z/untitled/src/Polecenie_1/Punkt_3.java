package Polecenie_1;

public class Punkt_3 {

    public URL resourceUrl; // Zmienna jasno określająca zasób
    private List<User> userList; // Wyraźnie określa, że to lista użytkowników
    public double[] dataTable; // Nazwa lepiej oddająca zawartość
}

