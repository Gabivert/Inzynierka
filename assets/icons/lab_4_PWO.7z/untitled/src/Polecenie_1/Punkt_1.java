package Polecenie_1;

public class Punkt_1 {

    public Date userRegistrationDate; //data rejestracji użytkownika
    public List<Item> UserPurchasedItems(User user) { … }; // znajdź przedmioty kupione przez użytkownika

}

