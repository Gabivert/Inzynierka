package Polecenie_1;

public class Punkt_2 {

    public Payments[] PaymentList;
    private int paymentInterestConstant; //
    protected ArrayList<Member> memberMap;

}

