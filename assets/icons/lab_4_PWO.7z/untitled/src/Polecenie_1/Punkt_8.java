package Polecenie_1;

public class Punkt_8 {

    public class Mammal {…}
    private class SecretPersistanceManager {…}
    public String getLoggedUserName(Date t){…}

}
