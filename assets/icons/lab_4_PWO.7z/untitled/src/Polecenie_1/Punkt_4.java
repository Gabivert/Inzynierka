package Polecenie_1;

public class Punkt_4 {

    public class TemperatureLoader{
        public double[] loadTemperature(File file){…} // zmiana nazwy zmiennej
        public File saveTemperature(double[] temperatures){…} //zmiana nazwy zmiennej
    }
    class DataWeather {
        private WindData windCreate(){…}
        private PressureData pressureCreate(){…}
        private TemperatureLoad temperaturesCreate(double[] temperatures){…}
    }

}
